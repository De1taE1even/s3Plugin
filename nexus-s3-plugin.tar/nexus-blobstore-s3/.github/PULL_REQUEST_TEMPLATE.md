(brief, plain english overview of your changes here)

This pull request makes the following changes:
* (your change here)
* (another change here)
* (etc)

(If there are changes to the UI, please include a screenshot so we
know what to look for!)

(If there are changes to user behavior in general, please make sure to
update the docs, as well)

It relates to the following issue #s:
* Fixes #X
